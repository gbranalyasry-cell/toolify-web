from flask import Flask, render_template, request, send_file, redirect, url_for
import os
from pdf2docx import Converter
from PIL import Image
import qrcode

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['OUTPUT_FOLDER'] = 'outputs'

@app.route('/')
def index():
    return render_template('index.html')

# PDF to Word
@app.route('/pdf', methods=['GET', 'POST'])
def pdf_to_word():
    if request.method == 'POST':
        file = request.files['pdf_file']
        if file:
            pdf_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
            word_path = os.path.join(app.config['OUTPUT_FOLDER'], file.filename.replace('.pdf', '.docx'))
            file.save(pdf_path)
            cv = Converter(pdf_path)
            cv.convert(word_path)
            cv.close()
            return send_file(word_path, as_attachment=True)
    return render_template('pdf.html')

# Image Compressor
@app.route('/image', methods=['GET', 'POST'])
def image_compress():
    if request.method == 'POST':
        file = request.files['img_file']
        if file:
            img_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
            out_path = os.path.join(app.config['OUTPUT_FOLDER'], file.filename)
            file.save(img_path)
            img = Image.open(img_path)
            img.save(out_path, optimize=True, quality=50)
            return send_file(out_path, as_attachment=True)
    return render_template('image.html')

# QR Generator
@app.route('/qr', methods=['GET', 'POST'])
def qr_generator():
    if request.method == 'POST':
        data = request.form['qr_data']
        if data:
            qr_img = qrcode.make(data)
            out_path = os.path.join(app.config['OUTPUT_FOLDER'], 'qrcode.png')
            qr_img.save(out_path)
            return send_file(out_path, as_attachment=True)
    return render_template('qr.html')
